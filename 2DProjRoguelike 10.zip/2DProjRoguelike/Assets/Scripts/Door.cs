﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : Interactable {

    public override void TriggerInteraction(Vector2 direction)
    {
        SpriteRenderer sprite = GetComponent<SpriteRenderer>();
        BoxCollider2D collider = GetComponent<BoxCollider2D>();
        StaticVisComponent vis = GetComponent<StaticVisComponent>();
        sprite.enabled = false;
        collider.enabled = false;
        Destroy(vis.hiddenMask.gameObject);
        vis.enabled = false;
    }
}
