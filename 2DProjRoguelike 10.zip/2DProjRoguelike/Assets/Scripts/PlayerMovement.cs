﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{

    private enum Direction { north = 0, south = 1, east = 2, west = 3 }

    // Public values can be adjusted in unity
    public int speed = 1;
    public int movementCooldown = 3;
    public int maxHealth = 10;
    public float xpGrowth = 0.5f;
    public float xpToLevel = 10;
    public static float totalxp;
    public BoxCollider2D[] directionalColliders = new BoxCollider2D[4];

    public GUIStyle style;

    public Weapon weapon;
    public Armor armor;
    public Shield shield;

    // Private values for behind the scenes work
    private int movementTimer = 0;
    [SerializeField]
    private int attack = 1;
    private int health;
    private float xp = 0;
    private int level = 1;
    private Direction direction;

    // Use this for initialization
    void Start()
    {
        health = maxHealth;
        // preserve player across scenes
        DontDestroyOnLoad(gameObject);
    }

    private void OnGUI()
    {
        string displayString = "HP: " + health.ToString() + " / " + maxHealth.ToString();
        displayString += "\n XP: " + xp.ToString() + " / " + xpToLevel.ToString();
        displayString += "\n Level: " + level.ToString();

        if (weapon != null)
        {
            displayString += "\n Weapon: " + weapon.itemName;
        }
        else
        {
            displayString += "\n Weapon: None";
        }

        if (armor != null)
        {
            displayString += "\n Armor: " + armor.itemName;
        }
        else
        {
            displayString += "\n Armor: None";
        }

        if (shield != null)
        {
            displayString += "\n Shield: " + shield.itemName;
        }
        else
        {
            displayString += "\n Shield: None";
        }

        GUI.Label(new Rect(Screen.width - 8 * 24, 10, 7 * 24, 6 * 36), displayString, style);
    }

    // Update is called once per frame
    void Update()
    {
        ControlPlayerHold();
        PlayerAttack();
        PlayerInteract();

        // check if going down stairs
        if (Input.GetKeyDown(KeyCode.Greater) || (Input.GetKeyDown(KeyCode.Period) && (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))))
        {
            int stairsMask = LayerMask.GetMask("Stairs");
            // check if there are stairs down at player's position
            if (Physics2D.OverlapBox(transform.position, new Vector2(0.25f, 0.25f), 0, stairsMask))
            {
                Debug.Log("down");
                foreach (var collider in directionalColliders)
                {
                    collider.GetComponent<EdgeTriggerTest>().blocked = false;
                }
                LevelGeneration gen = FindObjectOfType(typeof(LevelGeneration)) as LevelGeneration;
                if (gen != null)
                {
                    SceneManager.LoadScene(gen.dungeonDepth + 1);
                }
                else
                {
                    // when exit final floor, go to game over screen
                    Destroy(gameObject);
                }
            }
        }

        XPController();
        UpdateTimer();
    }

    void ControlPlayerHold()
    {
        // Used for moving the player
        Vector2 movePlayer = Vector2.zero;

        if (Input.GetKey(KeyCode.LeftArrow) && movementTimer == 0 && !directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.west;
            movePlayer += Vector2.left;
            movementTimer += movementCooldown;
        }
        if (Input.GetKey(KeyCode.RightArrow) && movementTimer == 0 && !directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.east;
            movePlayer += Vector2.right;
            movementTimer += movementCooldown;
        }
        if (Input.GetKey(KeyCode.UpArrow) && movementTimer == 0 && !directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.north;
            movePlayer += Vector2.up;
            movementTimer += movementCooldown;
        }
        if (Input.GetKey(KeyCode.DownArrow) && movementTimer == 0 && !directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.south;
            movePlayer += Vector2.down;
            movementTimer += movementCooldown;
        }

        transform.position = Vector2.MoveTowards(transform.position, transform.position + new Vector3(movePlayer.x, movePlayer.y, 0), speed);
        // transform.Translate(new Vector3(movePlayer.x, movePlayer.y, 0));

        // signals end of player turn
        if (movePlayer != Vector2.zero)
        {
            TurnManager.PlayerTurnOver();
        }
        else if (Input.GetKeyDown(KeyCode.Period) && movementTimer == 0)
        {
            TurnManager.PlayerTurnOver();
        }
    }

    void PlayerAttack()
    {
        if (Input.GetKey((KeyCode.LeftArrow)) && movementTimer == 0 && directionalColliders[3].GetComponent<EdgeTriggerTest>().blockedMonster)
        {
            Monster enemy = directionalColliders[3].GetComponent<EdgeTriggerTest>().collidingMonster;
            MessageQueue.PushMessage("You hit the " + enemy.monsterName + ".");
            enemy.TakeDamage(DamageDiceRoll());
            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
        if (Input.GetKey((KeyCode.RightArrow)) && movementTimer == 0 && directionalColliders[2].GetComponent<EdgeTriggerTest>().blockedMonster)
        {
            Monster enemy = directionalColliders[2].GetComponent<EdgeTriggerTest>().collidingMonster;
            MessageQueue.PushMessage("You hit the " + enemy.monsterName + ".");
            enemy.TakeDamage(DamageDiceRoll());
            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
        if (Input.GetKey((KeyCode.UpArrow)) && movementTimer == 0 && directionalColliders[0].GetComponent<EdgeTriggerTest>().blockedMonster)
        {
            Monster enemy = directionalColliders[0].GetComponent<EdgeTriggerTest>().collidingMonster;
            MessageQueue.PushMessage("You hit the " + enemy.monsterName + ".");
            enemy.TakeDamage(DamageDiceRoll());
            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
        if (Input.GetKey((KeyCode.DownArrow)) && movementTimer == 0 && directionalColliders[1].GetComponent<EdgeTriggerTest>().blockedMonster)
        {
            Monster enemy = directionalColliders[1].GetComponent<EdgeTriggerTest>().collidingMonster;
            MessageQueue.PushMessage("You hit the " + enemy.monsterName + ".");
            enemy.TakeDamage(DamageDiceRoll());
            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
    }

    void PlayerInteract()
    {
        if (Input.GetKey((KeyCode.LeftArrow)) && movementTimer == 0 && directionalColliders[3].GetComponent<EdgeTriggerTest>().blockedInteractable)
        {
            Interactable interact = directionalColliders[3].GetComponent<EdgeTriggerTest>().collidingInteractable;
            interact.TriggerInteraction(Vector2.left);

            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
        if (Input.GetKey((KeyCode.RightArrow)) && movementTimer == 0 && directionalColliders[2].GetComponent<EdgeTriggerTest>().blockedInteractable)
        {
            Interactable interact = directionalColliders[2].GetComponent<EdgeTriggerTest>().collidingInteractable;
            interact.TriggerInteraction(Vector2.right);

            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
        if (Input.GetKey((KeyCode.UpArrow)) && movementTimer == 0 && directionalColliders[0].GetComponent<EdgeTriggerTest>().blockedInteractable)
        {
            Interactable interact = directionalColliders[0].GetComponent<EdgeTriggerTest>().collidingInteractable;
            interact.TriggerInteraction(Vector2.up);

            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
        if (Input.GetKey((KeyCode.DownArrow)) && movementTimer == 0 && directionalColliders[1].GetComponent<EdgeTriggerTest>().blockedInteractable)
        {
            Interactable interact = directionalColliders[1].GetComponent<EdgeTriggerTest>().collidingInteractable;
            interact.TriggerInteraction(Vector2.down);

            movementTimer += movementCooldown;
            TurnManager.PlayerTurnOver();
        }
    }

    void UpdateTimer()
    {
        if (movementTimer > 0)
        {
            movementTimer--;
        }
    }

    public void ModifyHealth(int change)
    {
        health += change;
        // game over code goes here
        if (health <= 0)
        {

        }
        if (health > maxHealth)
        {
            health = maxHealth;
        }
    }


    public void GrantXP(float give)
    {
        xp += give;
        totalxp += give;
    }

    public void TakeDamage(int damage)
    {
        if (armor != null)
        {
            if (damage > armor.ac)
            {
                damage -= armor.ac;
            }
            else
            {
                damage = 0;
            }
        }

        if (shield != null)
        {
            if (Random.value < shield.blockChance)
            {
                damage = 0;
            }
        }

        health -= damage;
        if (health <= 0)
        {
            Destroy(gameObject);
        }
    }

    int DamageDiceRoll()
    {
        int damage;

        int dice1 = Random.Range(0, 7);
        int dice2 = Random.Range(0, 7);

        int weaponDamage = 0;
        if (weapon != null)
        {
            weaponDamage = weapon.damage;
        }

        if (dice1 == dice2 && dice1 == 6)
        {
            damage = (weaponDamage + attack) * 2;
        }
        else if (dice1 == dice2)
        {
            damage = weaponDamage + attack;
        }
        else if (dice1 != dice2 && dice1 == 0)
        {
            damage = 0;
        }
        else
        {
            damage = (weaponDamage + attack) / 2;
        }

        return damage;
    }


    void XPController()
    {
        if (xp == xpToLevel)
        {
            xp = 0;
            xpToLevel *= 1 + xpGrowth;
            xpToLevel = Mathf.Round(xpToLevel);
            level++;
            maxHealth += 5;
            attack += 1;
            health = maxHealth;
        }
        else if (xp > xpToLevel)
        {
            xp -= xpToLevel;
            xpToLevel *= 1 + xpGrowth;
            xpToLevel = Mathf.Round(xpToLevel);
            level++;
            maxHealth += 5;
            attack += 1;
            health = maxHealth;
        }
    }

    void OnDestroy()
    {
        SceneManager.LoadScene("endScreen");
    }
}