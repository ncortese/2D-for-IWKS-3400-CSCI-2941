﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This is a bit buggy and it's hard to tell where the projectile is going so I think I'm not going to include it
public class RangedProjectileMonster : Monster
{
    public GameObject projectile;
    public float shootProbability = 0.3f;

    protected override void TakeTurn()
    {
        if (Vector3.Distance(player.transform.position, transform.position) <= 1)
        {
            StartCoroutine(AttackPhase());
        }
        else if (Vector3.Distance(player.transform.position, transform.position) <= sight)
        {
            int sightBlockerMask = LayerMask.GetMask("SightBlocker");
            RaycastHit2D hit = Physics2D.Raycast(transform.position, player.transform.position - transform.position, Vector3.Distance(player.transform.position, transform.position), sightBlockerMask);
            // if have clear LOS to player, shoot at them (sometimes)
            if (hit.collider == null)
            {
                if (Random.value > shootProbability)
                {
                    float deltaX = player.transform.position.x - transform.position.x;
                    float deltaY = player.transform.position.y - transform.position.y;
                    if (Mathf.Abs(deltaX) > Mathf.Abs(deltaY))
                    {
                        GameObject newProjectile = Instantiate(projectile, transform.position + new Vector3(Mathf.Sign(deltaX), 0), Quaternion.identity);
                        newProjectile.GetComponent<Projectile>().SetTarget(player.transform.position);
                    }
                    else
                    {
                        GameObject newProjectile = Instantiate(projectile, transform.position + new Vector3(0, Mathf.Sign(deltaY)), Quaternion.identity);
                        newProjectile.GetComponent<Projectile>().SetTarget(player.transform.position);
                    }
                }
            }
            // if can't see player, walk towards them
            else
            {
                StartCoroutine(SlideMove(player.transform.position));
            }
        }
    }
    
}