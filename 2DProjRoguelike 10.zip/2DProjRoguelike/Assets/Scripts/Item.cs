﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour {
    public string itemName;
    public bool consumedOnUse;
    public bool isEquipment;
    public virtual void UseItem() { }
}
