﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloorInitializer : MonoBehaviour {
	void Start () {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        PlayerFOV fov = player.GetComponent<PlayerFOV>();
        TurnManager.StartListening(fov.CalculateFOV);
        fov.CalculateFOV();
    }
}
