﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VisComponent : MonoBehaviour {
    protected bool isVisible = false;
    protected SpriteRenderer sprite;

	// Use this for initialization
	public virtual void Awake () {
        sprite = GetComponent<SpriteRenderer>();
        sprite.enabled = false;
	}
	
	public virtual void SetVisible(bool vis)
    {
        if (vis && !isVisible)
        {
            sprite.enabled = true;
        }
        if (!vis && isVisible)
        {
            sprite.enabled = false;
        }
        isVisible = vis;
    }
}
