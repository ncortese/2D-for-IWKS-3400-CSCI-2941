﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInventory : MonoBehaviour {
    public List<Item> items;
    bool inventoryOpen;
    bool dropOpen;

    public GUIStyle style;

    private Dictionary<KeyCode, int> itemKeys;

    void Start()
    {
        // dictionary of keys corresponding to each possible index in items
        itemKeys = new Dictionary<KeyCode, int>();
        itemKeys.Add(KeyCode.A, 0);
        itemKeys.Add(KeyCode.B, 1);
        itemKeys.Add(KeyCode.C, 2);
        itemKeys.Add(KeyCode.D, 3);
        itemKeys.Add(KeyCode.E, 4);
        itemKeys.Add(KeyCode.F, 5);
        itemKeys.Add(KeyCode.G, 6);
        itemKeys.Add(KeyCode.H, 7);
        itemKeys.Add(KeyCode.I, 8);
        itemKeys.Add(KeyCode.J, 9);
        itemKeys.Add(KeyCode.K, 10);
        itemKeys.Add(KeyCode.L, 11);
        itemKeys.Add(KeyCode.M, 12);
        itemKeys.Add(KeyCode.N, 13);
        itemKeys.Add(KeyCode.O, 14);
        itemKeys.Add(KeyCode.P, 15);
        itemKeys.Add(KeyCode.Q, 16);
        itemKeys.Add(KeyCode.R, 17);
        itemKeys.Add(KeyCode.S, 18);
        itemKeys.Add(KeyCode.T, 19);
        itemKeys.Add(KeyCode.U, 20);
        itemKeys.Add(KeyCode.V, 21);
        itemKeys.Add(KeyCode.W, 22);
        itemKeys.Add(KeyCode.X, 23);
        itemKeys.Add(KeyCode.Y, 24);
        itemKeys.Add(KeyCode.Z, 25);
    }

	// Update is called once per frame
	void Update () {
        // picking up items
        if (Input.GetKeyDown(KeyCode.G))
        {
            int itemMask = LayerMask.GetMask("Item");
            // check if there are stairs down at player's position
            Collider2D itemCollider = new Collider2D();
            itemCollider = Physics2D.OverlapBox(transform.position, new Vector2(0.25f, 0.25f), 0, itemMask);
            if (itemCollider != null && items.Count < 26)
            {
                Item item = itemCollider.gameObject.GetComponent<Item>();
                items.Add(item);
                item.gameObject.SetActive(false);
                // this is necessary to preserve items in inventory when go down stairs
                DontDestroyOnLoad(item.gameObject);
                TurnManager.PlayerTurnOver();
            }
        }

        // using items
        if (inventoryOpen)
        {
            foreach (KeyValuePair<KeyCode, int> keyIndex in itemKeys)
            {
                if (Input.GetKeyDown(keyIndex.Key) && items.Count >= keyIndex.Value + 1)
                {
                    Item item = items[keyIndex.Value];
                    item.UseItem();
                    TurnManager.PlayerTurnOver();
                    if (item.consumedOnUse)
                    {
                        items.Remove(item);
                        Destroy(item);
                        inventoryOpen = false;
                    }
                }
            }
        }

        // opening and closing inventory
        if (Input.GetKeyDown(KeyCode.I) && !inventoryOpen) {
            inventoryOpen = true;
        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            inventoryOpen = false;
        }
        
    }

    void OnGUI()
    {
        if (inventoryOpen)
        {
            string itemString = "Inventory \n";
            char itemChar = 'a';
            int longestName = 9;
            foreach(Item item in items)
            {
                longestName = Mathf.Max(longestName, item.itemName.Length);
                itemString += itemChar + " - " + item.itemName + "\n";
                ++itemChar;
            }
            GUI.Label(new Rect(10, 10, longestName*24 + 24, items.Count * 36 + 36), itemString, style);
            // GUI.Box(new Rect(10, 10, 100, items.Count * 24 + 24), "Inventory");
        }
    }
}
