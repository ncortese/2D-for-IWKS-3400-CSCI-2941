﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Potion : Item {
    public int healthAmount;

	// Use this for initialization
	void Start () {
        consumedOnUse = true;
	}

    public override void UseItem()
    {
        PlayerMovement player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMovement>();
        player.ModifyHealth(healthAmount);
    }
}
