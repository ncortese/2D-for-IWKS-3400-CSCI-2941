﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EdgeTriggerTest : MonoBehaviour {

    public bool blocked;

	// Use this for initialization
	void Start () {
		
	}

    void OnTriggerEnter2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = true;
        }
    }

    void OnTriggerStay2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = true;
        }
    }

    void OnTriggerExit2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = false;
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
