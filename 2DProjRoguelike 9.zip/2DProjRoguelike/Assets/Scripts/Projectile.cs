﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// projectile moves in a fixed direction using a modified form of Bresenham's Line Algorithm
public class Projectile : MonoBehaviour {
    public int damage;

    private int d_x = 0;
    private int d_y = 0;
    private int increment_x = 0;
    private int increment_y = 0;
    private int eps = 0;
    public BoxCollider2D[] directionalColliders = new BoxCollider2D[4];
    int xMoveCollider;
    int yMoveCollider;

    private void OnEnable()
    {
        TurnManager.StartListening(TakeTurn);
    }

    private void OnDisable()
    {
        TurnManager.StopListening(TakeTurn);
    }

    public void SetTarget(Vector2 target)
    {
        Vector2Int intTarget = Vector2Int.RoundToInt(target);
        Vector2Int intCurrentPos = Vector2Int.RoundToInt(transform.position);
        if (intTarget.x > intCurrentPos.x)
        {
            increment_x = 1;
            xMoveCollider = 2;
        }
        if (intTarget.x < intCurrentPos.x)
        {
            increment_x = -1;
            xMoveCollider = 3;
        }
        if (intTarget.y > intCurrentPos.y)
        {
            increment_y = 1;
            yMoveCollider = 0;
        }
        if (intTarget.y < intCurrentPos.y)
        {
            increment_y = -1;
            yMoveCollider = 1;
        }
        d_x = (intTarget.x - intCurrentPos.x) * increment_x;
        d_y = (intTarget.y - intCurrentPos.y) * increment_y;
    }

    void TakeTurn()
    {
        bool yHit = false;
        bool xHit = false;

        if (d_x > d_y)
        {
            if (eps >= d_x)
            {
                if (directionalColliders[yMoveCollider].GetComponent<EdgeTriggerTest>().blocked)
                {
                    yHit = true;
                }
                else
                {
                    transform.position += new Vector3(0, increment_y);
                    eps -= d_x;
                }
            }
            else
            {
                if (directionalColliders[xMoveCollider].GetComponent<EdgeTriggerTest>().blocked)
                {
                    xHit = true;
                }
                else
                {
                    transform.position += new Vector3(increment_x, 0);
                    eps += d_y;
                }
            }
        }
        else if (d_x < d_y)
        {
            if (eps >= d_y)
            {
                if (directionalColliders[xMoveCollider].GetComponent<EdgeTriggerTest>().blocked)
                {
                    xHit = true;
                }
                else
                {
                    transform.position += new Vector3(increment_x, 0);
                    eps -= d_y;
                }
            }
            else
            {
                if (directionalColliders[yMoveCollider].GetComponent<EdgeTriggerTest>().blocked)
                {
                    yHit = true;
                }
                else
                {
                    transform.position += new Vector3(0, increment_y);
                    eps += d_x;
                }
            }
        }
        else
        {
            if (eps % 2 == 0)
            {
                if (directionalColliders[xMoveCollider].GetComponent<EdgeTriggerTest>().blocked)
                {
                    xHit = true;
                }
                else
                {
                    transform.position += new Vector3(increment_x, 0);
                }
            }
            else
            {
                if (directionalColliders[yMoveCollider].GetComponent<EdgeTriggerTest>().blocked)
                {
                    yHit = true;
                }
                else
                {
                    transform.position += new Vector3(0, increment_y);
                }
            }
            ++eps;
        }

        // now handle collisions
        if (xHit)
        {
            if (directionalColliders[xMoveCollider].GetComponent<EdgeTriggerTest>().blockedPlayer)
            {
                directionalColliders[xMoveCollider].GetComponent<EdgeTriggerTest>().collidingPlayer.TakeDamage(damage);
            }
            else if (directionalColliders[xMoveCollider].GetComponent<EdgeTriggerTest>().blockedMonster)
            {
                directionalColliders[xMoveCollider].GetComponent<EdgeTriggerTest>().collidingMonster.TakeDamage(damage);
            }
            Destroy(gameObject);
        }
        else if (yHit)
        {
            if (directionalColliders[yMoveCollider].GetComponent<EdgeTriggerTest>().blockedPlayer)
            {
                directionalColliders[yMoveCollider].GetComponent<EdgeTriggerTest>().collidingPlayer.TakeDamage(damage);
            }
            else if (directionalColliders[yMoveCollider].GetComponent<EdgeTriggerTest>().blockedMonster)
            {
                directionalColliders[yMoveCollider].GetComponent<EdgeTriggerTest>().collidingMonster.TakeDamage(damage);
            }
            Destroy(gameObject);
        }
    }
}
