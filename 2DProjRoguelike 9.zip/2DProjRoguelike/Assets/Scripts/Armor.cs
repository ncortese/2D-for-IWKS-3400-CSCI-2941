﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Armor : Item {
    public int ac;

	// Use this for initialization
	void Start () {
        isEquipment = true;
    }

    public override void UseItem()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        PlayerMovement playerMove = player.GetComponent<PlayerMovement>();
        PlayerInventory playerInvent = player.GetComponent<PlayerInventory>();
        Item prevArmor = playerMove.armor;
        if (prevArmor != null)
        {
            playerInvent.items.Add(prevArmor);
        }
        playerMove.armor = this;
    }
}
