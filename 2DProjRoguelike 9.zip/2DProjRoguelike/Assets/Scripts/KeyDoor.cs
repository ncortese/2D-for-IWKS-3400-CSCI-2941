﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyDoor : Door
{
    public string keyName;

    public override void TriggerInteraction(Vector2 direction)
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        PlayerInventory playerInvent = player.GetComponent<PlayerInventory>();
        foreach (Item i in playerInvent.items)
        {
            if (i.itemName == keyName)
            {
                playerInvent.items.Remove(i);
                base.TriggerInteraction(direction);
                break;
            }
        }
    }
}