﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(BoxCollider2D))]
public class MouseHover : MonoBehaviour {

    public Color onColor = Color.red;
    public Color offColor = Color.white;

    private Renderer render;

	// Use this for initialization
	void Start () {
        render = GetComponent<Renderer>();
        render.material.color = offColor;
	}

    void OnMouseEnter() {
        render.material.color = onColor;
    }

    void OnMouseExit() {
        render.material.color = offColor;
    }
	
}
