﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageScroll : Item {

	// Use this for initialization
	void Start () {
        consumedOnUse = true;
	}

    public override void UseItem()
    {
        
    }
}
