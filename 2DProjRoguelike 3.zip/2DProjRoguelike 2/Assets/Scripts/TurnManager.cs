﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class TurnManager : MonoBehaviour {
    UnityEvent playerTurnOver;
    private static TurnManager turnManager;

    // this is used to have a unique global TurnManager
    public static TurnManager instance
    {
        get
        {
            if (turnManager == null)
            {
                Debug.Log("new turn manager");
                turnManager = FindObjectOfType(typeof (TurnManager)) as TurnManager;
                if (!turnManager)
                {
                    Debug.LogError("need TurnManager script on an object in scene");
                }
                else
                {
                    turnManager.Init();
                }
            }
            return turnManager;
        }
    }

    void Init()
    {
        playerTurnOver = new UnityEvent();
    }

	// Use this for initialization
	void Start () {
		
	}
	
	public static void StartListening(UnityAction listener)
    {
        instance.playerTurnOver.AddListener(listener);
    }

    public static void StopListening(UnityAction listener)
    {
        if (turnManager == null)
        {
            return;
        }
        instance.playerTurnOver.RemoveListener(listener);
    }

    // called by the player object after it ends its turn
    public static void PlayerTurnOver()
    {
        instance.playerTurnOver.Invoke();
    }
}
