﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageScroll : Item {
    public int damageAmount;

	// Use this for initialization
	void Start () {
        consumedOnUse = true;
	}

    public override void UseItem()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        Collider2D[] adjColliders = Physics2D.OverlapBoxAll(player.transform.position, new Vector2(2, 2), 0);
        foreach (Collider2D c in adjColliders)
        {
            Debug.Log(c.gameObject.tag);
            if (c.gameObject.tag == "Monster")
            {
                Monster mon = c.gameObject.GetComponent<Monster>();
                mon.TakeDamage(damageAmount);
            }
        }
    }
}
