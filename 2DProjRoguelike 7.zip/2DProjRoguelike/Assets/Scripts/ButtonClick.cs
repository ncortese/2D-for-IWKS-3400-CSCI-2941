﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


[RequireComponent(typeof(BoxCollider2D))]
public class ButtonClick : MonoBehaviour {

    public ButtonType type;

    public enum ButtonType { Start, Exit, Restart, Score }

    void OnMouseDown() {
        if (type == ButtonType.Start) {
            SceneManager.LoadScene("floor1");
        }
        if (type == ButtonType.Exit) {
            Application.Quit();
            UnityEditor.EditorApplication.isPlaying = false;
        }
        if (type == ButtonType.Restart) {
            SceneManager.LoadScene("floor1");
        }
        if (type == ButtonType.Score) {

        }
    }
}
