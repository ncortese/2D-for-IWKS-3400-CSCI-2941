﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PushBlock : Interactable
{

    public override void TriggerInteraction(Vector2 direction)
    {
        if (!Physics2D.OverlapBox((Vector2)transform.position + direction, new Vector2(0.25f, 0.25f), 0))
        {
            transform.position = (Vector2)transform.position + direction;
        }
    }
}
