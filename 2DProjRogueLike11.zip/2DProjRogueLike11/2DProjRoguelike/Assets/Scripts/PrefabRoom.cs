﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrefabRoom : GeneralRoom
{
    private List<string> prefabString;
    private int centerLine;
    private int centerColumn;
    public LevelGeneration parentGenerator;

    public PrefabRoom(ref List<string> allPrefabs, IntVec2D containingCell, bool usingLeftExit, bool usingUpExit, bool usingRightExit, bool usingDownExit, LevelGeneration parentGenerator)
    {
        this.containingCell = containingCell;
        this.parentGenerator = parentGenerator;

        prefabString = new List<string>();
        SelectPrefab(ref allPrefabs);
        centerLine = prefabString.Count / 2;
        centerColumn = prefabString[0].Length / 2;
        // crude way to ensure all prefab exits match up (all mandatory exits are used by cell, all cell exits exist in prefab):
        // randomly selects prefabs until finds one that works. Potentially slow
        while (!InitializePrefab(usingLeftExit, usingUpExit, usingRightExit, usingDownExit))
        {
            Debug.Log("had to re-select prefab");
            prefabString = new List<string>();
            leftExit = null;
            upExit = null;
            rightExit = null;
            downExit = null;
            SelectPrefab(ref allPrefabs);
            centerLine = prefabString.Count / 2;
            centerColumn = prefabString[0].Length / 2;
        }
    }

    // get empty spaces inside room
    public override void GetFreeSpaceList(ref List<Vector2> freeSpaces)
    {
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                char c = prefabString[y][x];
                IntVec2D worldPos = StringPosToWorldPos(x, y);
                if (prefabString[y][x] == '.' || prefabString[y][x] == ',')
                {
                    freeSpaces.Add(new Vector2(worldPos.x, worldPos.y));
                }
            }
        }
    }

    // get spaces where can spawn inside room (different from free spaces, since can have free spaces where spawning
    // is prohibited)
    public override void GetSpawnSpaceList(ref List<Vector2> freeSpaces)
    {
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                char c = prefabString[y][x];
                IntVec2D worldPos = StringPosToWorldPos(x, y);
                if (prefabString[y][x] == '.')
                {
                    freeSpaces.Add(new Vector2(worldPos.x, worldPos.y));
                }
            }
        }
    }

    // test if space is inside room and not a wall
    public override bool IsSpaceInside(Vector2 space)
    {
        IntVec2D spaceint = new IntVec2D(Mathf.RoundToInt(space.x), Mathf.RoundToInt(space.y));
        IntVec2D stringspaceint = WorldPosToStringPos(spaceint.x, spaceint.y);
        char c = prefabString[stringspaceint.y][stringspaceint.x];
        return (c == '.' || c == ',');
    }

    public override void BuildRoom()
    {
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                char c = prefabString[y][x];
                IntVec2D worldPos = StringPosToWorldPos(x, y);
                if (c == ' ' || c == '.' || c == 'l' || c == 'u' || c == 'r' || c == 'd' || c == '-')
                {
                    continue;
                }
                // place wall
                else if (c == '#')
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                // place water
                else if (c == '~')
                {
                    GameObject water = Resources.Load("Objects/Water") as GameObject;
                    parentGenerator.CreateObject(water, worldPos.x, worldPos.y);
                }
                // place trees
                else if (c == 'T')
                {
                    GameObject tree = Resources.Load("Objects/Tree") as GameObject;
                    parentGenerator.CreateObject(tree, worldPos.x, worldPos.y);
                }
                // place lava
                else if (c == '=')
                {
                    GameObject lava = Resources.Load("Objects/Lava") as GameObject;
                    parentGenerator.CreateObject(lava, worldPos.x, worldPos.y);
                }
                // place tombstones
                else if (c == 'n')
                {
                    GameObject tombstone = Resources.Load("Objects/Tombstone") as GameObject;
                    parentGenerator.CreateObject(tombstone, worldPos.x, worldPos.y);
                }
                // place doors
                else if (c == '+')
                {
                    GameObject door = Resources.Load("Objects/Door") as GameObject;
                    parentGenerator.CreateObject(door, worldPos.x, worldPos.y);
                }
                // place red key doors
                else if (c == 'E')
                {
                    GameObject door = Resources.Load("Objects/Red key door") as GameObject;
                    parentGenerator.CreateObject(door, worldPos.x, worldPos.y);
                }
                // place blue key doors
                else if (c == 'B')
                {
                    GameObject door = Resources.Load("Objects/Blue key door") as GameObject;
                    parentGenerator.CreateObject(door, worldPos.x, worldPos.y);
                }
                // place green key doors
                else if (c == 'G')
                {
                    GameObject door = Resources.Load("Objects/Green key door") as GameObject;
                    parentGenerator.CreateObject(door, worldPos.x, worldPos.y);
                }
                // place red key
                else if (c == 'e')
                {
                    GameObject key = Resources.Load("Items/Red key") as GameObject;
                    parentGenerator.CreateObject(key, worldPos.x, worldPos.y);
                }
                // place blue key
                else if (c == 'b')
                {
                    GameObject key = Resources.Load("Items/Blue key") as GameObject;
                    parentGenerator.CreateObject(key, worldPos.x, worldPos.y);
                }
                // place green key
                else if (c == 'g')
                {
                    GameObject key = Resources.Load("Items/Green key") as GameObject;
                    parentGenerator.CreateObject(key, worldPos.x, worldPos.y);
                }
                // place push block
                else if (c == 'P')
                {
                    GameObject block = Resources.Load("Objects/PushBlock") as GameObject;
                    parentGenerator.CreateObject(block, worldPos.x, worldPos.y);
                }
                // place small potion
                else if (c == '1')
                {
                    GameObject potion = Resources.Load("Items/Small potion") as GameObject;
                    parentGenerator.CreateObject(potion, worldPos.x, worldPos.y);
                }
                // place medium potion
                else if (c == '2')
                {
                    GameObject potion = Resources.Load("Items/Medium potion") as GameObject;
                    parentGenerator.CreateObject(potion, worldPos.x, worldPos.y);
                }
                // place large potion
                else if (c == '3')
                {
                    GameObject potion = Resources.Load("Items/Large potion") as GameObject;
                    parentGenerator.CreateObject(potion, worldPos.x, worldPos.y);
                }
                // place full potion
                else if (c == '4')
                {
                    GameObject potion = Resources.Load("Items/Full potion") as GameObject;
                    parentGenerator.CreateObject(potion, worldPos.x, worldPos.y);
                }
                // place random item
                else if (c == 'I')
                {
                    int randItemIndex = UnityEngine.Random.Range(0, parentGenerator.items.Length);
                    GameObject item = parentGenerator.items[randItemIndex];
                    parentGenerator.CreateObject(item, worldPos.x, worldPos.y);
                }
                // place random monster
                else if (c == 'M')
                {
                    int randItemIndex = UnityEngine.Random.Range(0, parentGenerator.monsters.Length);
                    GameObject monster = parentGenerator.monsters[randItemIndex];
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place bat
                else if (c == 'a')
                {
                    GameObject monster = Resources.Load("Monsters/Bat") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place snake? dog?
                else if (c == 's')
                {
                    GameObject monster = Resources.Load("Monsters/Snake") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place skeleton or whatever it is
                else if (c == 'x')
                {
                    GameObject monster = Resources.Load("Monsters/Skeleton") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place zombie
                else if (c == 'z')
                {
                    GameObject monster = Resources.Load("Monsters/Zombie") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place goblin
                else if (c == 'i')
                {
                    GameObject monster = Resources.Load("Monsters/Goblin") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place orc
                else if (c == 'o')
                {
                    GameObject monster = Resources.Load("Monsters/Orc") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place centaur
                else if (c == 'c')
                {
                    GameObject monster = Resources.Load("Monsters/Centaur") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place demon
                else if (c == 'm')
                {
                    GameObject monster = Resources.Load("Monsters/Demon") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place troll
                else if (c == 't')
                {
                    GameObject monster = Resources.Load("Monsters/Troll") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place keeper
                else if (c == 'k')
                {
                    GameObject monster = Resources.Load("Monsters/Keeper") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place necromancer
                else if (c == 'N')
                {
                    GameObject monster = Resources.Load("Monsters/Necromancer") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place goblin matron
                else if (c == 'Q')
                {
                    GameObject monster = Resources.Load("Monsters/Goblin Matron") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place demon archer
                else if (c == 'C')
                {
                    GameObject monster = Resources.Load("Monsters/Demon Archer") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // place arch demon
                else if (c == 'A')
                {
                    GameObject monster = Resources.Load("Monsters/Arch Demon") as GameObject;
                    parentGenerator.CreateObject(monster, worldPos.x, worldPos.y);
                }
                // if char is an exit that has been closed by the level generator, place a wall there
                else if (c == 'L' && leftExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                else if (c == 'U' && upExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                else if (c == 'R' && rightExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                else if (c == 'D' && downExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
            }
        }
    }

    private IntVec2D StringPosToWorldPos(int x, int y)
    {
        int worldX = x - centerColumn + containingCell.x * parentGenerator.cell_width;
        int worldY = -y + centerLine + containingCell.y * parentGenerator.cell_height;
        return new IntVec2D(worldX, worldY);
    }

    private IntVec2D WorldPosToStringPos(int x, int y)
    {
        int stringX = x + centerColumn - containingCell.x * parentGenerator.cell_width;
        int stringY = -y + centerLine + containingCell.y * parentGenerator.cell_height;
        return new IntVec2D(stringX, stringY);
    }

    private bool InitializePrefab(bool usingLeftExit, bool usingUpExit, bool usingRightExit, bool usingDownExit)
    {
        // iterate through prefab text to find empty space and exit positions
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                // check for exits
                if (prefabString[y][x] == 'L' && usingLeftExit)
                {
                    leftExit = StringPosToWorldPos(x, y);
                }
                else if (prefabString[y][x] == 'U' && usingUpExit)
                {
                    upExit = StringPosToWorldPos(x, y);
                }
                else if (prefabString[y][x] == 'R' && usingRightExit)
                {
                    rightExit = StringPosToWorldPos(x, y);
                }
                else if (prefabString[y][x] == 'D' && usingDownExit)
                {
                    downExit = StringPosToWorldPos(x, y);
                }
                // check for mandatory exits
                else if (prefabString[y][x] == 'l')
                {
                    leftExit = StringPosToWorldPos(x, y);
                    if (!usingLeftExit)
                    {
                        return false;
                    }
                }
                else if (prefabString[y][x] == 'u')
                {
                    upExit = StringPosToWorldPos(x, y);
                    if (!usingUpExit)
                    {
                        return false;
                    }
                }
                else if (prefabString[y][x] == 'r')
                {
                    rightExit = StringPosToWorldPos(x, y);
                    if (!usingRightExit)
                    {
                        return false;
                    }
                }
                else if (prefabString[y][x] == 'd')
                {
                    downExit = StringPosToWorldPos(x, y);
                    if (!usingDownExit)
                    {
                        return false;
                    }
                }
            }
        }
        // check if prefab lacks any required exits
        if (leftExit == null && usingLeftExit)
        {
            return false;
        }
        if (upExit == null && usingUpExit)
        {
            return false;
        }
        if (rightExit == null && usingRightExit)
        {
            return false;
        }
        if (downExit == null && usingDownExit)
        {
            return false;
        }
        return true;
    }

    // randomly select a prefab to spawn
    private void SelectPrefab(ref List<string> allPrefabs)
    {
        // select random prefab
        int numPrefabs = Int32.Parse(allPrefabs[0]);
        int randomPrefab = (int)(numPrefabs * UnityEngine.Random.value) + 1;
        // iterate through prefabs to find selected
        string currentString = allPrefabs[0];
        int currentLine = 0;
        int currentPrefab = 0;
        while (true)
        {
            // */ marks beginning of each prefab
            if (currentString.StartsWith("*/"))
            {
                ++currentPrefab;
            }
            if (currentPrefab == randomPrefab)
            {
                ++currentLine;
                currentString = allPrefabs[currentLine];
                // /* marks end of each prefab
                while (!currentString.StartsWith("/*"))
                {
                    prefabString.Add(currentString);
                    ++currentLine;
                    currentString = allPrefabs[currentLine];

                    if (currentString == null)
                    {
                        Debug.LogError("prefab selection error");
                        break;
                    }
                }
                break;
            }
            // if pass end, some kind of error must have occurred
            else if (currentPrefab == numPrefabs)
            {
                Debug.LogError("prefab selection error");
                break;
            }
            if (currentString == null)
            {
                Debug.LogError("prefab selection error");
                break;
            }

            ++currentLine;
            currentString = allPrefabs[currentLine];
        }
    }
}