﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RangedHitscanMonster : Monster {
    public int rangedAttack;
    public int shootRange = 4;

    protected override void TakeTurn()
    {
        if (Vector3.Distance(player.transform.position, transform.position) <= 1)
        {
            StartCoroutine(AttackPhase());
        }
        else if (Vector3.Distance(player.transform.position, transform.position) <= sight)
        {
            int sightBlockerMask = LayerMask.GetMask("SightBlocker");
            RaycastHit2D hit = Physics2D.Raycast(transform.position, player.transform.position - transform.position, Vector3.Distance(player.transform.position, transform.position), sightBlockerMask);
            // if have clear LOS to player and player is within shooting range (should be 1 less than sight to not be annoying), shoot at them
            if (hit.collider == null && Vector3.Distance(player.transform.position, transform.position) <= shootRange)
            {
                MessageQueue.PushMessage("The " + monsterName + " shoots you.");
                player.GetComponent<PlayerMovement>().TakeDamage(RangedDamageDiceRoll());
            }
            // if can't see player, walk towards them
            else
            {
                StartCoroutine(SlideMove(player.transform.position));
            }
        }
    }

    int RangedDamageDiceRoll()
    {
        int damage;

        int dice1 = Random.Range(0, 7);
        int dice2 = Random.Range(0, 7);

        // no crits and higher miss chance for ranged attacks
        if (dice1 <= 2)
        {
            damage = 0;
        }
        else
        {
            damage = rangedAttack;
        }

        return damage;
    }
}
