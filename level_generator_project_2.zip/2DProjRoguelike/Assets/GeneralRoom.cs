﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// base class for random and prefab rooms
public abstract class GeneralRoom {
    public IntVec2D leftExit;
    public IntVec2D upExit;
    public IntVec2D rightExit;
    public IntVec2D downExit;

    public IntVec2D containingCell;

    // function that builds tiles in room
    public abstract void BuildRoom();
    // function that returns true if space is a floor tile inside room
    public abstract bool IsSpaceInside(Vector2 space);
    // gets list of spaces inside room that aren't walls (for, e.g., teleporting to a random position in a random room)
    public abstract void GetFreeSpaceList(ref List<Vector2> freeSpaces);
    // gets list of spaces inside room that objects can be spawned at
    public abstract void GetSpawnSpaceList(ref List<Vector2> freeSpaces);
}

// randomly generated rectangular rooms
public class RandomRoom: GeneralRoom
{
    public IntVec2D bottomLeftCorner;
    public IntVec2D topRightCorner;
    public LevelGeneration parentGenerator;

    public RandomRoom(IntVec2D bottomLeftCorner, IntVec2D topRightCorner, IntVec2D containingCell, bool usingLeftExit, bool usingUpExit, bool usingRightExit, bool usingDownExit, LevelGeneration parentGenerator)
    {
        this.bottomLeftCorner = bottomLeftCorner;
        this.topRightCorner = topRightCorner;
        this.containingCell = containingCell;
        this.parentGenerator = parentGenerator;

        int leftCorridorY = (int)((topRightCorner.y - bottomLeftCorner.y - 2) * UnityEngine.Random.value + bottomLeftCorner.y + 1);
        int rightCorridorY = (int)((topRightCorner.y - bottomLeftCorner.y - 2) * UnityEngine.Random.value + bottomLeftCorner.y + 1);
        int upCorridorX = (int)((topRightCorner.x - bottomLeftCorner.x - 2) * UnityEngine.Random.value + bottomLeftCorner.x + 1);
        int downCorridorX = (int)((topRightCorner.x - bottomLeftCorner.x - 2) * UnityEngine.Random.value + bottomLeftCorner.x + 1);
        if (usingLeftExit)
        {
            leftExit = new IntVec2D(bottomLeftCorner.x, leftCorridorY);
        }
        if (usingRightExit)
        {
            rightExit = new IntVec2D(topRightCorner.x, rightCorridorY);
        }
        if (usingUpExit)
        {
            upExit = new IntVec2D(upCorridorX, topRightCorner.y);
        }
        if (usingDownExit)
        {
            downExit = new IntVec2D(downCorridorX, bottomLeftCorner.y);
        }
    }

    public override bool IsSpaceInside(Vector2 space)
    {
        return (space.x > bottomLeftCorner.x && space.x < topRightCorner.x && space.y > bottomLeftCorner.y && space.y < topRightCorner.y);
    }

    // construct list of free spaces
    public override void GetFreeSpaceList(ref List<Vector2> freeSpaces)
    {
        for (int x = bottomLeftCorner.x + 1; x < topRightCorner.x; ++x)
        {
            for (int y = bottomLeftCorner.y + 1; y < topRightCorner.y; ++y)
            {
                freeSpaces.Add(new Vector2(x, y));
            }
        }
    }

    // construct list of spaces where can spawn (in random room case, same as free space list. In prefabs can be different)
    public override void GetSpawnSpaceList(ref List<Vector2> freeSpaces)
    {
        for (int x = bottomLeftCorner.x + 1; x < topRightCorner.x; ++x)
        {
            for (int y = bottomLeftCorner.y + 1; y < topRightCorner.y; ++y)
            {
                freeSpaces.Add(new Vector2(x, y));
            }
        }
    }

    public override void BuildRoom()
    {
        // create top and bottom horizontal walls
        for (int x = bottomLeftCorner.x; x <= topRightCorner.x; ++x)
        {
            if (!isInExits(new IntVec2D(x, bottomLeftCorner.y)))
            {
                parentGenerator.CreateWall(x, bottomLeftCorner.y);
            }
            if (!isInExits(new IntVec2D(x, topRightCorner.y)))
            {
                parentGenerator.CreateWall(x, topRightCorner.y);
            }
        }
        // create left and right vertical walls (skipping top and bottom to avoid creating corners twice)
        for (int y = bottomLeftCorner.y + 1; y < topRightCorner.y; ++y)
        {
            if (!isInExits(new IntVec2D(bottomLeftCorner.x, y)))
            {
                parentGenerator.CreateWall(bottomLeftCorner.x, y);
            }
            if (!isInExits(new IntVec2D(topRightCorner.x, y)))
            {
                parentGenerator.CreateWall(topRightCorner.x, y);
            }
        }
    }

    private bool isInExits(IntVec2D pos)
    {
        if (leftExit != null)
        {
            if (leftExit.Equals(pos))
            {
                return true;
            }
        }
        if (upExit != null)
        {
            if (upExit.Equals(pos))
            {
                return true;
            }
        }
        if (rightExit != null)
        {
            if (rightExit.Equals(pos))
            {
                return true;
            }
        }
        if (downExit != null)
        {
            if (downExit.Equals(pos))
            {
                return true;
            }
        }
        return false;
    }

    private bool isInExits(Vector2 pos)
    {
        int x = Mathf.RoundToInt(pos.x);
        int y = Mathf.RoundToInt(pos.y);
        IntVec2D intPos = new IntVec2D(x, y);
        if (leftExit != null)
        {
            if (leftExit.Equals(intPos))
            {
                return true;
            }
        }
        if (upExit != null)
        {
            if (upExit.Equals(intPos))
            {
                return true;
            }
        }
        if (rightExit != null)
        {
            if (rightExit.Equals(intPos))
            {
                return true;
            }
        }
        if (downExit != null)
        {
            if (downExit.Equals(intPos))
            {
                return true;
            }
        }
        return false;
    }
}