﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// just an example of how the turn-taking behavior works. Make sure to include both the OnEnable and OnDisable
// functions as is, and put the code that needs to be executed on the enemy's turn in the TakeTurn function
public class ExampleMonsterMovement : MonoBehaviour {
    GameObject player;

    private void OnEnable()
    {
        TurnManager.StartListening(TakeTurn);
    }

    private void OnDisable()
    {
        TurnManager.StopListening(TakeTurn);
    }

	// Use this for initialization
	void Start () {
        player = GameObject.FindGameObjectWithTag("Player");
	}
	
	void TakeTurn()
    {
        transform.position += new Vector3(Mathf.Sign((player.transform.position - transform.position).x), Mathf.Sign((player.transform.position - transform.position).y));
    }
}
