﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerFOV : MonoBehaviour {
    Transform playerPos;
    int sightBlockerMask;
    public int viewRadius = 5;
    public float viewRadiusEps = 0.1f;

    private void OnEnable()
    {
        TurnManager.StartListening(CalculateFOV);
    }

    private void OnDisable()
    {
        TurnManager.StopListening(CalculateFOV);
    }

    // Use this for initialization
    void Start () {
        playerPos = GetComponent<Transform>();
        sightBlockerMask = LayerMask.GetMask("SightBlocker");
        CalculateFOV();
	}
	
	void CalculateFOV()
    {
        // set everything to not visible, store list of nearby GameObjects that aren't SightBlockers
        List<VisComponent> nearbyVisObjects = new List<VisComponent>(); 
        VisComponent[] visObjects = FindObjectsOfType(typeof (VisComponent)) as VisComponent[];
        foreach (VisComponent vO in visObjects)
        {
            vO.SetVisible(false);
            if (Vector3.Distance(vO.transform.position, transform.position) <= viewRadius + viewRadiusEps && vO.gameObject.layer != LayerMask.NameToLayer("SightBlocker"))
            {
                nearbyVisObjects.Add(vO);
            }
        }

        // raycast at all tiles in range. If nothing blocking sight to tile, set objects at that tile and all adjacent
        // walls to visible.
        // Originally, I set wall visibility based on what got hit by the raycast itself; this was more efficient, but led to visual artifacts.
        for (int x = -viewRadius; x <= viewRadius; ++x)
        {
            for (int y = -viewRadius; y <= viewRadius; ++y)
            {
                Vector2Int tilePosition = new Vector2Int(x, y);
                if (tilePosition.magnitude <= viewRadius + viewRadiusEps)
                {
                    RaycastHit2D hit = Physics2D.Raycast(transform.position, tilePosition, tilePosition.magnitude, sightBlockerMask);
                    if (hit.collider == null)
                    {
                        Vector2 worldTilePosition = tilePosition + (Vector2)transform.position;
                        // check for walls in a box large enough to overlap all adjacent tiles
                        Collider2D[] adjWalls = Physics2D.OverlapBoxAll(worldTilePosition, new Vector2(1, 1), 0, sightBlockerMask);
                        foreach (Collider2D c in adjWalls)
                        {
                            VisComponent wallVis = c.gameObject.GetComponent<VisComponent>();
                            if (wallVis != null)
                            {
                                wallVis.SetVisible(true);
                            }
                        }
                        foreach (VisComponent vO in nearbyVisObjects)
                        {
                            if ((vO.transform.position.x < worldTilePosition.x + viewRadiusEps && vO.transform.position.x > worldTilePosition.x - viewRadiusEps) && (vO.transform.position.y < worldTilePosition.y + viewRadiusEps && vO.transform.position.y > worldTilePosition.y - viewRadiusEps))
                            {
                                vO.SetVisible(true);
                            }
                        }
                    }
                }
            }
        }
    }
}
