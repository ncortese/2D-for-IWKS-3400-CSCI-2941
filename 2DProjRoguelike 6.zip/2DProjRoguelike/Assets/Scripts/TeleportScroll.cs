﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeleportScroll : Item {

	// Use this for initialization
	void Start () {
        consumedOnUse = true;
    }

    public override void UseItem()
    {
        LevelGeneration gen = GameObject.FindGameObjectWithTag("LevelGenerator").GetComponent<LevelGeneration>();
        List<Vector2> freeSpaces = SampleRoom(ref gen);
        int spaceNum = Random.Range(0, freeSpaces.Count);
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        player.transform.position = freeSpaces[spaceNum];
        // player.GetComponent<PlayerFOV>().CalculateFOV();
    }

    private List<Vector2> SampleRoom(ref LevelGeneration gen)
    {
        int roomNum = Random.Range(0, gen.rooms.Count);
        GeneralRoom room = gen.rooms[roomNum];
        List<Vector2> freeSpaces = new List<Vector2>();
        room.GetFreeSpaceList(ref freeSpaces);
        List<Vector2> actualFreeSpaces = new List<Vector2>();
        // iterate through free spaces and check if actually empty
        foreach (Vector2 v in freeSpaces)
        {
            if (!Physics2D.OverlapBox(v, new Vector2(0.5f, 0.5f), 0))
            {
                actualFreeSpaces.Add(v);
            }
        }
        // if room has no available spaces, sample another room until you find one
        if (actualFreeSpaces.Count > 0)
        {
            return actualFreeSpaces;
        }
        else
        {
            return SampleRoom(ref gen);
        }
    }
}
