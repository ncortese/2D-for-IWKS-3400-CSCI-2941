﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// visibility for static objects like walls. Aids navigation by drawing parts of the level that you can't currently
// see, but have already explored, but draws in shadow to distinguish from currently visible
public class StaticVisComponent : VisComponent
{
    bool wasVisible = false;
    public SpriteRenderer hiddenMask;

    // Use this for initialization
    public override void Awake()
    {
        hiddenMask.enabled = false;
        base.Awake();
    }

    public override void SetVisible(bool vis)
    {
        wasVisible = wasVisible || vis;
        if (vis && !isVisible)
        {
            sprite.enabled = true;
            hiddenMask.enabled = false;
        }
        else if (!vis && isVisible && !wasVisible)
        {
            sprite.enabled = false;
        }
        else if (!vis && isVisible && wasVisible)
        {
            hiddenMask.enabled = true;
        }
        isVisible = vis;
    }
}
