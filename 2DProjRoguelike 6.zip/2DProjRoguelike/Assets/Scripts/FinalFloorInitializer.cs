﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinalFloorInitializer : MonoBehaviour {

	// Use this for initialization
	void Start () {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        player.transform.position = new Vector2(0, 0);
        PlayerFOV fov = player.GetComponent<PlayerFOV>();
        TurnManager.StartListening(fov.CalculateFOV);
        fov.CalculateFOV();
    }
}
