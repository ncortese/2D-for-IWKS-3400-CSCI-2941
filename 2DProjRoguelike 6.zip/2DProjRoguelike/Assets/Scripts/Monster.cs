﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour {
    GameObject player;

    public string monsterName;
    public int maxHp;
    public int hp;
    public int xp;
    public int gp;
    public int sight;
    public int tier;
    public int attack;

    private enum Direction { north = 0, south = 1, east = 2, west = 3 }
    public BoxCollider2D[] directionalColliders = new BoxCollider2D[4];

    private void OnEnable()
    {
        TurnManager.StartListening(TakeTurn);
    }

    private void OnDisable()
    {
        TurnManager.StopListening(TakeTurn);
    }

    // Use this for initialization
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        hp = maxHp;
    }

    public void TakeDamage(int damage)
    {
        hp -= damage;
        if (hp <= 0)
        {
            Destroy(gameObject);
        }
    }


    void OnDestroy()
    {
        if (player != null)
        {
            MessageQueue.PushMessage("The " + monsterName + " dies.");
            player.GetComponent<PlayerMovement>().GrantXP(xp);
        }
    }

    IEnumerator SlideMove(Vector3 targetPosition)
    {
        yield return new WaitForFixedUpdate();

        float deltaXTest = Mathf.Abs(targetPosition.x - transform.position.x);
        float deltaYTest = Mathf.Abs(targetPosition.y - transform.position.y);

        // change to stop weird movement caused by float imprecision
        int deltaX = 0;
        int deltaY = 0;
        if (Mathf.RoundToInt(targetPosition.x) > Mathf.RoundToInt(transform.position.x))
        {
            deltaX = 1;
        }
        else if (Mathf.RoundToInt(targetPosition.x) < Mathf.RoundToInt(transform.position.x))
        {
            deltaX = -1;
        }

        if (Mathf.RoundToInt(targetPosition.y) > Mathf.RoundToInt(transform.position.y))
        {
            deltaY = 1;
        }
        else if (Mathf.RoundToInt(targetPosition.y) < Mathf.RoundToInt(transform.position.y))
        {
            deltaY = -1;
        }

        bool moveDir = deltaXTest > deltaYTest; // true move x, false move y

        Vector3 move = Vector3.zero;

        if (deltaY > 0 && !directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Not blocked, move up
            move.y = 1;
        }
        else if (deltaY > 0 && directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Blocked, move in x
            if (deltaX > 0)
            {
                if (!directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.x = 1;
                }
            }
            else if (deltaX != 0)
            {
                if (!directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.x = -1;
                }
            }
        }
        if (deltaY < 0 && !directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Not blocked, move down
            move.y = -1;
        }
        else if (deltaY < 0 && directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Blocked, move in x
            if (deltaX > 0)
            {
                if (!directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.x = 1;
                }
            }
            else if (deltaX != 0)
            {
                if (!directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.x = -1;
                }
            }
        }
        if (deltaX > 0 && !directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Not blocked, move right
            move.x = 1;
        }
        else if (deltaX > 0 && directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Blocked, move in y
            if (deltaY > 0)
            {
                if (!directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.y = 1;
                }
            }
            else if (deltaY != 0)
            {
                if (!directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.y = -1;
                }
            }
        }
        if (deltaX < 0 && !directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Not blocked, move left
            move.x = -1;
        }
        else if (deltaX < 0 && directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Blocked, move in y
            if (deltaY > 0)
            {
                if (!directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.y = 1;
                }
            }
            else if (deltaY != 0)
            {
                if (!directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked)
                {
                    move.y = -1;
                }
            }
        }

        // test to see if problem is with monster move code
        if (move.x < 0 && directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked)
        {
            move.x = 0;
        }

        if (move.x > 0 && directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked)
        {
            move.x = 0;
        }

        if (move.y < 0 && directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked)
        {
            move.y = 0;
        }

        if (move.y > 0 && directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked)
        {
            move.y = 0;
        }

        transform.position += move;
        // transform.Translate(move);
    }

    IEnumerator AttackPhase()
    {
        yield return new WaitForFixedUpdate();

        bool blocks = false;
        for (int i = 0; i < 4; ++i)
        {
            if (directionalColliders[i].GetComponent<EdgeTriggerTest>().blockedPlayer)
            {
                blocks = true;
            }
        }

        if (blocks)
        {
            MessageQueue.PushMessage("The " + monsterName + " hits you.");
            player.GetComponent<PlayerMovement>().TakeDamage(DamageDiceRoll());
        }
    }

    void TakeTurn()
    {
        // basic AI
        if (Vector3.Distance(player.transform.position, transform.position) < sight)
        {
            StartCoroutine(SlideMove(player.transform.position));
        }
        if (Vector3.Distance(player.transform.position, transform.position) <= 1)
        {
            StartCoroutine(AttackPhase());
        }
    }

    int DamageDiceRoll()
    {
        int damage;

        int dice1 = Random.Range(0, 7);
        int dice2 = Random.Range(0, 7);

        if (dice1 == dice2 && dice1 == 6)
        {
            damage = attack * 2;
        }
        else if (dice1 == dice2)
        {
            damage = attack;
        }
        else if (dice1 != dice2 && dice1 == 0)
        {
            damage = 0;
        }
        else
        {
            damage = attack / 2;
        }

        return damage;
    }
}
