﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EdgeTriggerTest : MonoBehaviour {

    public bool blocked;
	public bool blockedMonster;
	public bool blockedPlayer;
	public bool attack;

	public Monster collidingMonster;
    public PlayerMovement collidingPlayer;

	// Use this for initialization
	void Start () {
		
	}

    void OnTriggerEnter2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = true;
        }
		if (other.gameObject.tag == "Monster") {
			blockedMonster = true;
			if (gameObject.tag == "Player Collider") {
				blocked = true;
				collidingMonster = other.gameObject.GetComponent<Monster>();
			}
            if (gameObject.tag == "Monster Collider") {
                blocked = true;
            }
		}
		if (other.gameObject.tag == "Player") {
			blockedPlayer = true;
			if (gameObject.tag == "Monster Collider") {
				blocked = true;
				collidingPlayer = other.gameObject.GetComponent<PlayerMovement>();
			}
		}
    }

    void OnTriggerStay2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = true;
        }
		if (other.gameObject.tag == "Monster") {
			blockedMonster = true;
			if (gameObject.tag == "Player Collider") {
				blocked = true;
				collidingMonster = other.gameObject.GetComponent<Monster>();
			}
            if (gameObject.tag == "Monster Collider") {
                blocked = true;
            }
        }
		if (other.gameObject.tag == "Player") {
			blockedPlayer = true;
			if (gameObject.tag == "Monster Collider") {
				blocked = true;
				collidingMonster = other.gameObject.GetComponent<Monster>();
			}
		}
    }

    void OnTriggerExit2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = false;
        }
		if (other.gameObject.tag == "Monster") {
			blockedMonster = false;
			if (gameObject.tag == "Player Collider") {
				blocked = false;
			}
            if (gameObject.tag == "Monster Collider") {
                blocked = false;
            }
        }
		if (other.gameObject.tag == "Player") {
			blockedPlayer = false;
			if (gameObject.tag == "Monster Collider") {
				blocked = false;
			}
		}
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
