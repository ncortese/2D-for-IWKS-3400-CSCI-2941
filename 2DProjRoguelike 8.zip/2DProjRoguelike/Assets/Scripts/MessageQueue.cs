﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MessageQueue : MonoBehaviour {
    public List<string> messages;
    private int head = 0;
    public GUIStyle style;
    public GUIStyle style2;
    private static MessageQueue queue;

    // used to have single unique MessageQueue
    public static MessageQueue instance
    {
        get
        {
            if (queue == null)
            {
                queue = FindObjectOfType(typeof(MessageQueue)) as MessageQueue;
                if (!queue)
                {
                    Debug.LogError("need a message queue object in each scene");
                }
                else
                {
                    queue.Init();
                }
            }
            return queue;
        }
    }

    void Init()
    {
        messages = new List<string>();
    }

    int mod(int x, int m)
    {
        return (x % m + m) % m;
    }

    private void OnGUI()
    {
        string displayString = "";
        if (messages.Count > 0)
        {
            displayString = messages[messages.Count - 1];
        }
        string displayString2 = "\n";
        for (int i = messages.Count - 2; i >= 0; --i)
        {
            displayString2 = displayString2 + messages[i] + "\n";
        }
        GUI.Label(new Rect(10, Screen.height - 4 * 36, Screen.width - 10, 4 * 36), displayString, style);
        GUI.Label(new Rect(10, Screen.height - 4 * 36, Screen.width - 10, 3 * 36), displayString2, style2);
    }

    public static void PushMessage(string message)
    {
        instance.messages.Add(message);
        if (instance.messages.Count > 4)
        {
            instance.messages.RemoveAt(0);
        }
    }
}
