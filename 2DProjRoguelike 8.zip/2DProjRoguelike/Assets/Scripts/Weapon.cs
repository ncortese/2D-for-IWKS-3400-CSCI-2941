﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : Item {
    public int damage;

	// Use this for initialization
	void Start () {
        isEquipment = true;
	}

    public override void UseItem()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        PlayerMovement playerMove = player.GetComponent<PlayerMovement>();
        PlayerInventory playerInvent = player.GetComponent<PlayerInventory>();
        Item prevWeapon = playerMove.weapon;
        if (prevWeapon != null)
        {
            playerInvent.items.Add(prevWeapon);
        }
        playerMove.weapon = this;
    }
}
