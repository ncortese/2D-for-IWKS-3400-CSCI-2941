﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PrefabRoom : GeneralRoom
{
    private List<string> prefabString;
    private int centerLine;
    private int centerColumn;
    public LevelGeneration parentGenerator;

    public PrefabRoom(ref List<string> allPrefabs, IntVec2D containingCell, bool usingLeftExit, bool usingUpExit, bool usingRightExit, bool usingDownExit, LevelGeneration parentGenerator)
    {
        this.containingCell = containingCell;
        this.parentGenerator = parentGenerator;

        prefabString = new List<string>();
        SelectPrefab(ref allPrefabs);
        centerLine = prefabString.Count / 2;
        centerColumn = prefabString[0].Length / 2;
        // crude way to ensure all prefab exits match up (all mandatory exits are used by cell, all cell exits exist in prefab):
        // randomly selects prefabs until finds one that works. Potentially slow
        while (!InitializePrefab(usingLeftExit, usingUpExit, usingRightExit, usingDownExit))
        {
            Debug.Log("had to re-select prefab");
            prefabString = new List<string>();
            leftExit = null;
            upExit = null;
            rightExit = null;
            downExit = null;
            SelectPrefab(ref allPrefabs);
            centerLine = prefabString.Count / 2;
            centerColumn = prefabString[0].Length / 2;
        }
    }

    // get empty spaces inside room
    public override void GetFreeSpaceList(ref List<Vector2> freeSpaces)
    {
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                char c = prefabString[y][x];
                IntVec2D worldPos = StringPosToWorldPos(x, y);
                if (prefabString[y][x] == '.' || prefabString[y][x] == ',')
                {
                    freeSpaces.Add(new Vector2(worldPos.x, worldPos.y));
                }
            }
        }
    }

    // get spaces where can spawn inside room (different from free spaces, since can have free spaces where spawning
    // is prohibited)
    public override void GetSpawnSpaceList(ref List<Vector2> freeSpaces)
    {
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                char c = prefabString[y][x];
                IntVec2D worldPos = StringPosToWorldPos(x, y);
                if (prefabString[y][x] == '.')
                {
                    freeSpaces.Add(new Vector2(worldPos.x, worldPos.y));
                }
            }
        }
    }

    // test if space is inside room and not a wall
    public override bool IsSpaceInside(Vector2 space)
    {
        IntVec2D spaceint = new IntVec2D(Mathf.RoundToInt(space.x), Mathf.RoundToInt(space.y));
        IntVec2D stringspaceint = WorldPosToStringPos(spaceint.x, spaceint.y);
        char c = prefabString[stringspaceint.y][stringspaceint.x];
        return (c == '.' || c == ',');
    }

    public override void BuildRoom()
    {
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                char c = prefabString[y][x];
                IntVec2D worldPos = StringPosToWorldPos(x, y);
                if (c == ' ' || c == '.' || c == 'l' || c == 'u' || c == 'r' || c == 'd' || c == '-')
                {
                    continue;
                }
                // place wall
                else if (c == '#')
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                // place water
                else if (c == '~')
                {
                    GameObject water = Resources.Load("Objects/Water") as GameObject;
                    parentGenerator.CreateObject(water, worldPos.x, worldPos.y);
                }
                // place trees
                else if (c == 'T')
                {
                    GameObject tree = Resources.Load("Objects/Tree") as GameObject;
                    parentGenerator.CreateObject(tree, worldPos.x, worldPos.y);
                }
                // place lava
                else if (c == '=')
                {
                    GameObject lava = Resources.Load("Objects/Lava") as GameObject;
                    parentGenerator.CreateObject(lava, worldPos.x, worldPos.y);
                }
                // place tombstones
                else if (c == 'n')
                {
                    GameObject tombstone = Resources.Load("Objects/Tombstone") as GameObject;
                    parentGenerator.CreateObject(tombstone, worldPos.x, worldPos.y);
                }
                // if char is an exit that has been closed by the level generator, place a wall there
                else if (c == 'L' && leftExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                else if (c == 'U' && upExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                else if (c == 'R' && rightExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
                else if (c == 'D' && downExit == null)
                {
                    parentGenerator.CreateWall(worldPos.x, worldPos.y);
                }
            }
        }
    }

    private IntVec2D StringPosToWorldPos(int x, int y)
    {
        int worldX = x - centerColumn + containingCell.x * parentGenerator.cell_width;
        int worldY = -y + centerLine + containingCell.y * parentGenerator.cell_height;
        return new IntVec2D(worldX, worldY);
    }

    private IntVec2D WorldPosToStringPos(int x, int y)
    {
        int stringX = x + centerColumn - containingCell.x * parentGenerator.cell_width;
        int stringY = -y + centerLine + containingCell.y * parentGenerator.cell_height;
        return new IntVec2D(stringX, stringY);
    }

    private bool InitializePrefab(bool usingLeftExit, bool usingUpExit, bool usingRightExit, bool usingDownExit)
    {
        // iterate through prefab text to find empty space and exit positions
        for (int y = 0; y < prefabString.Count; ++y)
        {
            for (int x = 0; x < prefabString[0].Length; ++x)
            {
                // check for exits
                if (prefabString[y][x] == 'L' && usingLeftExit)
                {
                    leftExit = StringPosToWorldPos(x, y);
                }
                else if (prefabString[y][x] == 'U' && usingUpExit)
                {
                    upExit = StringPosToWorldPos(x, y);
                }
                else if (prefabString[y][x] == 'R' && usingRightExit)
                {
                    rightExit = StringPosToWorldPos(x, y);
                }
                else if (prefabString[y][x] == 'D' && usingDownExit)
                {
                    downExit = StringPosToWorldPos(x, y);
                }
                // check for mandatory exits
                else if (prefabString[y][x] == 'l')
                {
                    leftExit = StringPosToWorldPos(x, y);
                    if (!usingLeftExit)
                    {
                        return false;
                    }
                }
                else if (prefabString[y][x] == 'u')
                {
                    upExit = StringPosToWorldPos(x, y);
                    if (!usingUpExit)
                    {
                        return false;
                    }
                }
                else if (prefabString[y][x] == 'r')
                {
                    rightExit = StringPosToWorldPos(x, y);
                    if (!usingRightExit)
                    {
                        return false;
                    }
                }
                else if (prefabString[y][x] == 'd')
                {
                    downExit = StringPosToWorldPos(x, y);
                    if (!usingDownExit)
                    {
                        return false;
                    }
                }
            }
        }
        // check if prefab lacks any required exits
        if (leftExit == null && usingLeftExit)
        {
            return false;
        }
        if (upExit == null && usingUpExit)
        {
            return false;
        }
        if (rightExit == null && usingRightExit)
        {
            return false;
        }
        if (downExit == null && usingDownExit)
        {
            return false;
        }
        return true;
    }

    // randomly select a prefab to spawn
    private void SelectPrefab(ref List<string> allPrefabs)
    {
        // select random prefab
        int numPrefabs = Int32.Parse(allPrefabs[0]);
        int randomPrefab = (int)(numPrefabs * UnityEngine.Random.value) + 1;
        // iterate through prefabs to find selected
        string currentString = allPrefabs[0];
        int currentLine = 0;
        int currentPrefab = 0;
        while (true)
        {
            // */ marks beginning of each prefab
            if (currentString.StartsWith("*/"))
            {
                ++currentPrefab;
            }
            if (currentPrefab == randomPrefab)
            {
                ++currentLine;
                currentString = allPrefabs[currentLine];
                // /* marks end of each prefab
                while (!currentString.StartsWith("/*"))
                {
                    prefabString.Add(currentString);
                    ++currentLine;
                    currentString = allPrefabs[currentLine];
                }
                break;
            }
            // if pass end, some kind of error must have occurred
            else if (currentPrefab == numPrefabs)
            {
                Debug.Log("prefab selection error");
                break;
            }

            ++currentLine;
            currentString = allPrefabs[currentLine];
        }
    }
}