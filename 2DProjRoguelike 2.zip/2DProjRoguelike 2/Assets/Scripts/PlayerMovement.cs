﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{

    private enum Direction { north = 0, south = 1, east = 2, west = 3 }

    // Public values can be adjusted in unity
    public int speed = 1;
    public int movementCooldown = 3;
    public int maxHealth = 10;
    public float xpGrowth = 0.15f;
    public float xpToLevel = 10;
    public BoxCollider2D[] directionalColliders = new BoxCollider2D[4];

    // Private values for behind the scenes work
    private int movementTimer = 0;
    private int health;
    private float xp = 0;
    private int level = 1;
    private Direction direction;

    // Use this for initialization
    void Start()
    {
        health = maxHealth;
        // preserve player across scenes
        DontDestroyOnLoad(gameObject);
    }

    // Update is called once per frame
    void Update()
    {
        ControlPlayerHold();

        // check if going down stairs
        if (Input.GetKeyDown(KeyCode.Greater) || (Input.GetKeyDown(KeyCode.Period) && (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))))
        {
            int stairsMask = LayerMask.GetMask("Stairs");
            // check if there are stairs down at player's position
            if (Physics2D.OverlapBox(transform.position, new Vector2(0.25f, 0.25f), 0, stairsMask))
            {
                Debug.Log("down");
                LevelGeneration gen = FindObjectOfType(typeof(LevelGeneration)) as LevelGeneration;
                SceneManager.LoadScene(gen.dungeonDepth);
            }
        }

        XPController();
        UpdateTimer();
    }

	private void FixedUpdate()
	{
		PlayerAttack();
	}

	void ControlPlayerHold()
    {
        // Used for moving the player
        Vector2 movePlayer = Vector2.zero;

        if (Input.GetKey(KeyCode.LeftArrow) && movementTimer == 0 && !directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.west;
            movePlayer += Vector2.left;
            movementTimer += movementCooldown;
        }
        if (Input.GetKey(KeyCode.RightArrow) && movementTimer == 0 && !directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.east;
            movePlayer += Vector2.right;
            movementTimer += movementCooldown;
        }
        if (Input.GetKey(KeyCode.UpArrow) && movementTimer == 0 && !directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.north;
            movePlayer += Vector2.up;
            movementTimer += movementCooldown;
        }
        if (Input.GetKey(KeyCode.DownArrow) && movementTimer == 0 && !directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked)
        {
            direction = Direction.south;
            movePlayer += Vector2.down;
            movementTimer += movementCooldown;
        }

        transform.position = Vector2.MoveTowards(transform.position, transform.position + new Vector3(movePlayer.x, movePlayer.y, 0), speed);

        // signals end of player turn
        if (movePlayer != Vector2.zero)
        {
            TurnManager.PlayerTurnOver();
        }
    }

	void PlayerAttack() {
		if (Input.GetKey((KeyCode.LeftArrow)) && !directionalColliders[3].GetComponent<EdgeTriggerTest>().blockedMonster) {
			directionalColliders[3].GetComponent<EdgeTriggerTest>().collider.TakeDamage(2);
		}
		if (Input.GetKey((KeyCode.RightArrow)) && !directionalColliders[2].GetComponent<EdgeTriggerTest>().blockedMonster) {
			directionalColliders[2].GetComponent<EdgeTriggerTest>().collider.TakeDamage(2);
		}
		if (Input.GetKey((KeyCode.UpArrow)) && !directionalColliders[0].GetComponent<EdgeTriggerTest>().blockedMonster) {
			directionalColliders[0].GetComponent<EdgeTriggerTest>().collider.TakeDamage(2);
		}
		if (Input.GetKey((KeyCode.DownArrow)) && !directionalColliders[1].GetComponent<EdgeTriggerTest>().blockedMonster) {
			directionalColliders[1].GetComponent<EdgeTriggerTest>().collider.TakeDamage(2);
		}
	}

    void UpdateTimer()
    {
        if (movementTimer > 0)
        {
            movementTimer--;
        }
    }

    void XPController()
    {
        if (xp == xpToLevel)
        {
            xp = 0;
            xpToLevel *= xpGrowth;
            level++;
            maxHealth += 5;
            health = maxHealth;
        }
        else if (xp > xpToLevel)
        {
            xp -= xpToLevel;
            level++;
            maxHealth += 5;
            health = maxHealth;
        }
    }
}