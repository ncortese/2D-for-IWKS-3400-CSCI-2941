﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Monster : MonoBehaviour {
    GameObject player;

    public int maxHp;
    public int hp;
    public int xp;
    public int gp;
    public int sight;
    public int tier;

    private enum Direction { north = 0, south = 1, east = 2, west = 3 }
    public BoxCollider2D[] directionalColliders = new BoxCollider2D[4];

    private void OnEnable()
    {
        TurnManager.StartListening(TakeTurn);
    }

    private void OnDisable()
    {
        TurnManager.StopListening(TakeTurn);
    }

    // Use this for initialization
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        hp = maxHp;
    }

    public void TakeDamage(int damage)
    {
        hp -= damage;
        if (hp <= 0)
        {
            Destroy(gameObject);
        }
    }

    void SlideMove(Vector3 targetPosition)
    {
        float deltaXTest = Mathf.Abs(targetPosition.x - transform.position.x);
        float deltaYTest = Mathf.Abs(targetPosition.y - transform.position.y);
        Vector3 targetDelta = new Vector3(Mathf.Sign((targetPosition - transform.position).x), Mathf.Sign((targetPosition - transform.position).y));
        float deltaX = targetDelta.x;
        float deltaY = targetDelta.y;

        bool moveDir = deltaXTest > deltaYTest; // true move x, false move y

        Vector3 move = Vector3.zero;

        if (deltaY > 0 && !directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Not blocked, move up
            move.y = 1;
        }
        else if (deltaY > 0 && directionalColliders[0].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Blocked, move in x
            if (deltaX > 0)
            {
                move.x = 1;
            }
            else
            {
                move.x = -1;
            }
        }
        if (deltaY < 0 && !directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Not blocked, move down
            move.y = -1;
        }
        else if (deltaY < 0 && directionalColliders[1].GetComponent<EdgeTriggerTest>().blocked && !moveDir)
        {
            // Blocked, move in x
            if (deltaX > 0)
            {
                move.x = 1;
            }
            else
            {
                move.x = -1;
            }
        }
        if (deltaX > 0 && !directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Not blocked, move right
            move.x = 1;
        }
        else if (deltaX > 0 && directionalColliders[2].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Blocked, move in y
            if (deltaY > 0)
            {
                move.y = 1;
            }
            else
            {
                move.y = -1;
            }
        }
        if (deltaX < 0 && !directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Not blocked, move left
            move.x = -1;
        }
        else if (deltaX < 0 && directionalColliders[3].GetComponent<EdgeTriggerTest>().blocked && moveDir)
        {
            // Blocked, move in y
            if (deltaY > 0)
            {
                move.y = 1;
            }
            else
            {
                move.y = -1;
            }
        }

        transform.position += move;
    }

    void TakeTurn()
    {
        // basic AI
        if (Vector3.Distance(player.transform.position, transform.position) < sight)
        {
            SlideMove(player.transform.position);
        }
    }
}
