﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EdgeTriggerTest : MonoBehaviour {

    public bool blocked;
	public bool blockedMonster;
	public bool blockedPlayer;
	public bool attack;

	public Monster collider;

	// Use this for initialization
	void Start () {
		
	}

    void OnTriggerEnter2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = true;
        }
		if (other.gameObject.tag == "Monster") {
			blockedMonster = true;
			if (gameObject.tag == "Player Collider") {
				blocked = true;
				collider = other.gameObject.GetComponent<Monster>();
			}
		}
		if (other.gameObject.tag == "Player") {
			blockedPlayer = true;
			if (gameObject.tag == "Monster Collider") {
				blocked = true;
				collider = other.gameObject.GetComponent<Monster>();
			}
		}
    }

    void OnTriggerStay2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = true;
        }
		if (other.gameObject.tag == "Monster") {
			blockedMonster = true;
			if (gameObject.tag == "Player Collider") {
				blocked = true;
				collider = other.gameObject.GetComponent<Monster>();
			}
		}
		if (other.gameObject.tag == "Player") {
			blockedPlayer = true;
			if (gameObject.tag == "Monster Collider") {
				blocked = true;
				collider = other.gameObject.GetComponent<Monster>();
			}
		}
    }

    void OnTriggerExit2D(Collider2D other) {
        if (other.gameObject.tag == "Wall") {
            blocked = false;
        }
		if (other.gameObject.tag == "Monster") {
			blockedMonster = false;
			if (gameObject.tag == "Player Collider") {
				blocked = false;
			}
		}
		if (other.gameObject.tag == "Player") {
			blockedPlayer = false;
			if (gameObject.tag == "Monster Collider") {
				blocked = false;
			}
		}
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
